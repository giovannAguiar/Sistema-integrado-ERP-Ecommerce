require('dotenv').config();
const express = require('express');
const path = require('path');
const { connectDB } = require('./config/db');
const productRoutes = require('./routes/productRoutes');
const app = express();
const PORT = process.env.PORT;
 
connectDB();
 
app.use(express.json());
app.use(express.urlencoded({extended:true}));
 
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));
 
app.use(express.static(path.join(__dirname, 'public')));
 
app.use('/api/products', productRoutes);
 
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
 
app.get('/', (req,res) => {
    res.sendFile(path.join(__dirname, 'public/site', 'index.html'));
});
 
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
    console.log(`Frontend disponível em http://localhost:${PORT}/site`);
    console.log(`API de produtos em http://localhost:${PORT}/api/products`);
});